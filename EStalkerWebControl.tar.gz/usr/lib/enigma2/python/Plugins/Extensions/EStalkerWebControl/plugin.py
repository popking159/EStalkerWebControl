from twisted.web import server, resource
from twisted.internet import reactor
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigInteger, ConfigYesNo, ConfigSelection, ConfigText, getConfigListEntry
from Components.ConfigList import ConfigListScreen
import os
import json
import re
import socket
import requests
from requests.exceptions import RequestException
from enigma import getDesktop
import shutil
from datetime import datetime
from Components.ScrollLabel import ScrollLabel
# Configuration setup
config.plugins.StalkerWebControl = ConfigSubsection()
config.plugins.StalkerWebControl.port = ConfigInteger(default=8080, limits=(1, 65535))
config.plugins.StalkerWebControl.autostart = ConfigYesNo(default=False)
config.plugins.StalkerWebControl.backup_dir = ConfigText(default="/etc/enigma2/estalker/backups/", fixed_size=False)

class StalkerWebControlConfig(ConfigListScreen, Screen):
    skin = """
    <screen position="center,center" size="720,510" title="STALKER Web Control Configuration">
        <widget name="config" position="10,10" size="700,450" scrollbarMode="showOnDemand" font="Regular; 30" itemHeight="45" />
        <widget name="key_red" position="20,465" size="140,40" backgroundColor="background" font="Regular;28" valign="center" halign="center" />
        <widget name="key_green" position="220,465" size="140,40" backgroundColor="background" font="Regular;28" valign="center" halign="center" />
    <eLabel name="" position="10,465" size="10,40" backgroundColor="red" foregroundColor="red" />
<eLabel name="" position="210,465" size="10,40" backgroundColor="green" foregroundColor="green" />
</screen>
    """
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "MenuActions"],
        {
            "green": self.keySave,
            "red": self.keyCancel,
            "cancel": self.keyCancel,
            "ok": self.keySave,
            "menu": self.browsePaths,
        }, -2)
        
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=self.session)
        self.createSetup()
    
    def createSetup(self):
        self.list = [
            getConfigListEntry(_("Port number:"), config.plugins.StalkerWebControl.port),
            getConfigListEntry(_("Start automatically:"), config.plugins.StalkerWebControl.autostart),
            getConfigListEntry(_("Backup directory:"), config.plugins.StalkerWebControl.backup_dir),
        ]
        
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def browsePaths(self):
        from Screens.LocationBox import LocationBox
        
        current_entry = self["config"].getCurrent()
        if current_entry and current_entry[1] == config.plugins.StalkerWebControl.backup_dir:
            try:
                current_dir = config.plugins.StalkerWebControl.backup_dir.value
                if not os.path.exists(current_dir):
                    current_dir = "/"
            except:
                current_dir = "/"
                
            self.session.openWithCallback(
                self.pathSelected,
                LocationBox,
                _("Select backup directory"),
                currDir=current_dir,
                minFree=1,
                bookmarks=config.plugins.StalkerWebControl.backup_dir.value
            )

    def pathSelected(self, res):
        if res and len(res) > 1:  # Ensure we got a valid path
            current_entry = self["config"].getCurrent()
            if current_entry and current_entry[1] == config.plugins.StalkerWebControl.backup_dir:
                config.plugins.StalkerWebControl.backup_dir.value = res
                self["config"].invalidateCurrent()
                config.plugins.StalkerWebControl.backup_dir.save()
    
    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        
        # Ensure backup directory exists
        try:
            os.makedirs(config.plugins.StalkerWebControl.backup_dir.value, exist_ok=True)
        except Exception as e:
            self.session.open(MessageBox, _("Could not create backup directory:") + "\n" + str(e), MessageBox.TYPE_ERROR)
        
        self.close(True)
    
    def keyCancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close(False)

from Components.ScrollLabel import ScrollLabel

class StalkerWebControlScreen(Screen):
    skin = """
<screen position="center,center" size="800,600" title="STALKER Web Control">
    <widget name="status_label" position="10,10" size="780,40" font="Regular;28" />
    <widget name="count_label" position="10,60" size="780,30" font="Regular;20" />
    <widget name="info_label" position="10,100" size="780,440" font="Regular;22" transparent="1" />
    <ePixmap pixmap="skin_default/buttons/red.png" position="10,560" size="140,40" alphatest="on" />
    <ePixmap pixmap="skin_default/buttons/green.png" position="210,560" size="140,40" alphatest="on" />
    <ePixmap pixmap="skin_default/buttons/yellow.png" position="410,560" size="140,40" alphatest="on" />
    <ePixmap pixmap="skin_default/buttons/blue.png" position="610,560" size="140,40" alphatest="on" />
    <widget name="key_red" position="10,560" size="140,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
    <widget name="key_green" position="210,560" size="140,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
    <widget name="key_yellow" position="410,560" size="140,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
    <widget name="key_blue" position="610,560" size="140,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" />
</screen>
"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.web_running = False
        self.site = None
        self.listening_port = None
        self.playlist_file = self.get_playlist_file()
        self.mac_pattern = re.compile(r'^(00:1[aA]:79|A0:BB:3E):([0-9A-Fa-f]{2}:){2}[0-9A-Fa-f]{2}$', re.IGNORECASE)
        
        # Use ScrollLabel instead of regular Label
        self["info_label"] = ScrollLabel()
        
        self["count_label"] = Label("")
        self["status_label"] = Label("Server Status: Stopped")
        self["key_red"] = Button(_("Stop"))
        self["key_green"] = Button(_("Start"))
        self["key_yellow"] = Button(_("Config"))
        self["key_blue"] = Button(_("Backup/Restore"))
        
        self["actions"] = ActionMap(["DirectionActions", "OkCancelActions", "ColorActions"], {
            "up": self["info_label"].pageUp,
            "down": self["info_label"].pageDown,
            "left": self["info_label"].pageUp,
            "right": self["info_label"].pageDown,
            "red": self.stop_server,
            "green": self.start_server,
            "yellow": self.open_config,
            "blue": self.backup_restore,
            "cancel": self.close,
        }, -1)
        
        self.update_counts()
        self.update_playlists_display()

    def update_playlists_display(self):
        self.update_counts()
        ip = self.get_ip()
        port = config.plugins.StalkerWebControl.port.value
        playlists = self.get_current_playlists()
        
        # Verify actual server status
        if self.web_running and not self.verify_server_running():
            self.web_running = False
            self["status_label"].setText("Server Status: Stopped")
        
        content = f"Access web interface at: http://{ip}:{port}\n\nCurrent playlists:\n{playlists}"
        self["info_label"].setText(content)

    def verify_server_running(self):
        if not self.web_running or not self.listening_port:
            return False
        try:
            # Try to get the port number to verify it's actually running
            return bool(self.listening_port.getHost().port)
        except:
            return False

    def updateScroll(self):
        start = self.scroll_pos
        end = min(start + self.visible_lines, len(self.full_content))
        visible_content = '\n'.join(self.full_content[start:end])
        self["info_label"].setText(visible_content)

    def scrollUp(self):
        if self.scroll_pos > 0:
            self.scroll_pos -= 1
            self.updateScroll()

    def scrollDown(self):
        if self.scroll_pos < len(self.full_content) - self.visible_lines:
            self.scroll_pos += 1
            self.updateScroll()

    def pageUp(self):
        self.scroll_pos = max(0, self.scroll_pos - self.visible_lines)
        self.updateScroll()

    def pageDown(self):
        self.scroll_pos = min(len(self.full_content) - self.visible_lines, self.scroll_pos + self.visible_lines)
        self.updateScroll()

    def backup_restore(self):
        from Screens.ChoiceBox import ChoiceBox
        menu = [
            (_("Create Backup"), "backup"),
            (_("Restore Backup"), "restore"),
            (_("Set Backup Directory"), "set_backup_dir"),
        ]
        
        self.session.openWithCallback(
            self.backup_restore_callback,
            ChoiceBox,
            title=_("Backup/Restore Options"),
            list=menu
        )

    def backup_restore_callback(self, choice):
        if choice is None:
            return
            
        if choice[1] == "backup":
            self.backup_playlists()
        elif choice[1] == "restore":
            self.restore_playlists()
        elif choice[1] == "set_backup_dir":
            self.set_backup_directory()

    def set_backup_directory(self):
        from Screens.LocationBox import LocationBox
        try:
            current_dir = config.plugins.StalkerWebControl.backup_dir.value
            if not os.path.exists(current_dir):
                current_dir = "/"
        except:
            current_dir = "/"
            
        self.session.openWithCallback(
            self.backup_dir_selected,
            LocationBox,
            _("Select backup directory"),
            currDir=current_dir
        )

    def backup_dir_selected(self, res):
        if res is not None:
            try:
                config.plugins.StalkerWebControl.backup_dir.value = res
                config.plugins.StalkerWebControl.backup_dir.save()
                self.session.open(MessageBox, _("Backup directory set to:") + "\n" + res, MessageBox.TYPE_INFO)
            except Exception as e:
                self.session.open(MessageBox, _("Error setting backup directory:") + "\n" + str(e), MessageBox.TYPE_ERROR)

    def update_counts(self):
        portal_count = 0
        mac_count = 0
        try:
            if os.path.exists(self.playlist_file):
                with open(self.playlist_file, "r") as f:
                    content = f.read()
                    entries = [entry.strip() for entry in content.split('\n\n') if entry.strip()]
                    
                    for entry in entries:
                        lines = [line.strip() for line in entry.split('\n') if line.strip()]
                        if not lines:
                            continue
                        
                        if lines[0].startswith('http'):
                            portal_count += 1
                            mac_count += len([line for line in lines[1:] if self.mac_pattern.match(line)])
        except Exception as e:
            print(f"Error counting playlists: {str(e)}")
        
        self["count_label"].setText(f"Portals: {portal_count} | MACs: {mac_count}")

    def get_playlist_file(self):
        return "/etc/enigma2/estalker/e-portals.txt"
        
    def get_current_playlists(self):
        try:
            if not os.path.exists(self.playlist_file):
                return "No playlists file found"
                
            with open(self.playlist_file, "r") as f:
                content = f.read().strip()
                if not content:
                    return "No playlists configured"
                
                # Format the output with original MAC case
                formatted = []
                current_url = None
                for line in content.split('\n'):
                    line = line.strip()
                    if not line:
                        if current_url:
                            formatted.append("")  # Empty line between entries
                            current_url = None
                        continue
                    
                    if line.startswith("http"):
                        current_url = line
                        formatted.append(line)
                    elif current_url and self.mac_pattern.match(line):  # Use the screen's pattern
                        # Preserve original case
                        formatted.append(line)
                
                return '\n'.join(formatted)
        except Exception as e:
            return f"Error reading playlists: {str(e)}"
    
    def get_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "[your-ip]"
    
    def start_server(self):
        if not self.web_running:
            try:
                # Clean up any existing server first
                self.stop_server()
                
                # Create new server instance with connection tracking
                class ConnectionTrackingSite(server.Site):
                    def __init__(self, resource, screen):
                        super().__init__(resource)
                        self.screen = screen
                        self.connections = set()
                    
                    def buildProtocol(self, addr):
                        proto = super().buildProtocol(addr)
                        self.connections.add(proto)
                        return proto
                
                resource = StalkerWebControlResource(self)
                self.site = ConnectionTrackingSite(resource, self)
                self.listening_port = reactor.listenTCP(
                    config.plugins.StalkerWebControl.port.value, 
                    self.site, 
                    interface=''
                )
                self.web_running = True
                self["status_label"].setText("Server Status: Running")
                self.update_playlists_display()
                
            except Exception as e:
                self["status_label"].setText("Server Status: Error")
                self["info_label"].setText(f"Failed to start server: {str(e)}")
                self.web_running = False
                self.site = None
                self.listening_port = None
    
    def stop_server(self):
        if self.web_running:
            try:
                # Disconnect all active connections first
                if hasattr(self.site, 'connections'):
                    for connection in list(self.site.connections):
                        try:
                            connection.transport.loseConnection()
                        except:
                            pass
                
                # Stop the listening port
                if self.listening_port:
                    def stop_callback(result):
                        self.web_running = False
                        self["status_label"].setText("Server Status: Stopped")
                        self.site = None
                        self.listening_port = None
                        self.update_playlists_display()
                    
                    deferred = self.listening_port.stopListening()
                    deferred.addCallback(stop_callback)
                    deferred.addErrback(self.handle_stop_error)
                else:
                    self.web_running = False
                    self["status_label"].setText("Server Status: Stopped")
                    self.site = None
                    self.update_playlists_display()
                
            except Exception as e:
                self.handle_stop_error(Failure(e))

    def handle_stop_error(self, failure):
        self.web_running = False
        self.site = None
        self.listening_port = None
        self["status_label"].setText("Server Status: Error")
        error_msg = str(failure.value)
        self["info_label"].setText(f"Failed to stop server: {error_msg}\n\n{self.get_current_playlists()}")
        
        # Force garbage collection
        import gc
        gc.collect()

    def update_playlists_display(self):
        self.update_counts()
        ip = self.get_ip()
        port = config.plugins.StalkerWebControl.port.value
        playlists = self.get_current_playlists()
        
        # Verify actual server status
        if self.web_running:
            if not self.verify_server_status():
                self["status_label"].setText("Server Status: Stopped")
        
        status = "Running" if self.web_running else "Stopped"
        content = f"Server Status: {status}\n\nAccess web interface at: http://{ip}:{port}\n\nCurrent playlists:\n{playlists}"
        self["info_label"].setText(content)

    def verify_server_status(self):
        if self.web_running and self.listening_port:
            try:
                # Try to get the port number to verify it's actually running
                port = self.listening_port.getHost().port
                return True
            except:
                self.web_running = False
                self.site = None
                self.listening_port = None
                return False
        return not self.web_running

    def backup_playlists(self):
        try:
            backup_dir = config.plugins.StalkerWebControl.backup_dir.value
            if not os.path.exists(backup_dir):
                os.makedirs(backup_dir)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(backup_dir, f"estalker_playlists_backup_{timestamp}.txt")
            
            # Ensure source file exists
            if not os.path.exists(self.playlist_file):
                open(self.playlist_file, 'a').close()  # Create empty file if doesn't exist
                
            shutil.copy2(self.playlist_file, backup_file)
            self.session.open(MessageBox, 
                             _("Backup created successfully at:\n%s") % backup_file, 
                             MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, 
                             _("Backup failed: %s") % str(e), 
                             MessageBox.TYPE_ERROR)

    def restore_playlists(self):
        try:
            backup_dir = config.plugins.StalkerWebControl.backup_dir.value
            if not os.path.exists(backup_dir):
                self.session.open(MessageBox,
                                _("Backup directory does not exist"),
                                MessageBox.TYPE_ERROR)
                return
                
            backups = []
            for f in os.listdir(backup_dir):
                if f.startswith("estalker_playlists_backup_") and f.endswith(".txt"):
                    full_path = os.path.join(backup_dir, f)
                    if os.path.isfile(full_path):
                        backups.append((f, full_path))
            
            if not backups:
                self.session.open(MessageBox,
                                _("No valid backup files found"),
                                MessageBox.TYPE_ERROR)
                return
                
            # Sort by modification time (newest first)
            backups.sort(key=lambda x: os.path.getmtime(x[1]), reverse=True)
            
            from Screens.ChoiceBox import ChoiceBox
            self.session.openWithCallback(
                self.restore_selected_backup,
                ChoiceBox,
                title=_("Select backup to restore:"),
                list=[(backup[0], backup[1]) for backup in backups[:5]]  # Show last 5 backups
            )
        except Exception as e:
            self.session.open(MessageBox,
                             _("Restore failed: %s") % str(e),
                             MessageBox.TYPE_ERROR)

    def restore_selected_backup(self, choice):
        if choice is None:
            return
            
        backup_path = choice[1]
        try:
            # Create backup of current file before restoring
            current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
            recovery_file = os.path.join(config.plugins.StalkerWebControl.backup_dir.value,
                                       f"estalker_recovery_backup_{current_time}.txt")
            shutil.copy2(self.playlist_file, recovery_file)
            
            # Perform the restore
            shutil.copy2(backup_path, self.playlist_file)
            
            self.session.open(MessageBox,
                             _("Playlist restored successfully!\nOriginal saved as:\n%s") % recovery_file,
                             MessageBox.TYPE_INFO)
            self.update_playlists_display()
        except Exception as e:
            self.session.open(MessageBox,
                             _("Restore failed: %s") % str(e),
                             MessageBox.TYPE_ERROR)

    def open_config(self):
        self.session.openWithCallback(self.config_closed, StalkerWebControlConfig)
    
    def config_closed(self, result=None):
        if result:
            self.update_playlists_display()
            
            # Restart server if configuration changed while running
            if self.web_running:
                self.stop_server()
                self.start_server()

class StalkerWebControlResource(resource.Resource):
    isLeaf = True
    
    def __init__(self, screen):
        resource.Resource.__init__(self)
        self.screen = screen
        self.playlist_file = screen.playlist_file
        self.ensure_playlist_file()
        self.mac_pattern = screen.mac_pattern

    def cleanup(self):
        if hasattr(self.screen.site, 'connections'):
            for connection in list(self.screen.site.connections):
                try:
                    connection.transport.loseConnection()
                except:
                    pass

    def ensure_playlist_file(self):
        os.makedirs(os.path.dirname(self.playlist_file), exist_ok=True)
        if not os.path.exists(self.playlist_file):
            open(self.playlist_file, "w").close()
        
    def render_GET(self, request):
        if request.path == b"/api/backups":
            return self.list_backups(request)
        elif request.path == b"/":
            with open(os.path.join(os.path.dirname(__file__), "web/index.html"), "r") as f:
                return f.read().encode("utf-8")
        elif request.path == b"/style.css":
            with open(os.path.join(os.path.dirname(__file__), "web/style.css"), "r") as f:
                request.setHeader("Content-Type", "text/css")
                return f.read().encode("utf-8")
        elif request.path == b"/script.js":
            with open(os.path.join(os.path.dirname(__file__), "web/script.js"), "r") as f:
                request.setHeader("Content-Type", "application/javascript")
                return f.read().encode("utf-8")
        elif request.path == b"/api/playlists":
            return self.get_playlists(request)
        return b"404 Not Found"
        
    def render_POST(self, request):
        if request.path == b"/api/backup":
            return self.create_backup(request)
        elif request.path == b"/api/restore":
            return self.restore_backup(request)
        elif request.path == b"/api/update":
            return self.update_playlists(request)
        elif request.path == b"/api/validate":
            return self.validate_portal_mac(request)
        return b"404 Not Found"

    def list_backups(self, request):
        try:
            backup_dir = config.plugins.StalkerWebControl.backup_dir.value
            os.makedirs(backup_dir, exist_ok=True)
            
            backups = sorted(
                [f for f in os.listdir(backup_dir) if f.startswith("estalker_playlists_backup_")],
                reverse=True
            )
            
            return json.dumps({
                "success": True,
                "backups": backups[:10]  # Return last 10 backups
            }).encode("utf-8")
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e)
            }).encode("utf-8")

    def create_backup(self, request):
        try:
            backup_dir = config.plugins.StalkerWebControl.backup_dir.value
            os.makedirs(backup_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(backup_dir, f"estalker_playlists_backup_{timestamp}.txt")
            
            shutil.copy2(self.playlist_file, backup_file)
            
            return json.dumps({
                "success": True,
                "backup_file": backup_file
            }).encode("utf-8")
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e)
            }).encode("utf-8")

    def restore_backup(self, request):
        try:
            content = request.content.read().decode("utf-8")
            data = json.loads(content)
            backup_file = data.get("backup")
            
            if not backup_file:
                raise ValueError("No backup file specified")
                
            backup_path = os.path.join(config.plugins.StalkerWebControl.backup_dir.value, backup_file)
            
            if not os.path.exists(backup_path):
                raise ValueError("Backup file not found")
                
            shutil.copy2(backup_path, self.playlist_file)
            self.screen.update_playlists_display()
            
            return json.dumps({
                "success": True
            }).encode("utf-8")
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e)
            }).encode("utf-8")

    def get_playlists(self, request):
        try:
            playlists = []
            portal_count = 0
            mac_count = 0
            
            if os.path.exists(self.playlist_file):
                with open(self.playlist_file, "r") as f:
                    current_url = None
                    macs = []
                    
                    for line in f:
                        line = line.strip()
                        if not line:
                            if current_url and macs:  # End of a portal block
                                playlists.append({"url": current_url, "macs": macs})
                                current_url = None
                                macs = []
                            continue
                        
                        if line.startswith("http"):
                            if current_url:  # Finish previous portal if exists
                                playlists.append({"url": current_url, "macs": macs})
                                macs = []
                            current_url = line
                            portal_count += 1
                        elif current_url and self.mac_pattern.match(line):
                            # Keep in uppercase for display
                            macs.append(line.upper())
                            mac_count += 1
                    
                    # Add the last portal if exists
                    if current_url:
                        playlists.append({"url": current_url, "macs": macs})
            
            request.setHeader("Content-Type", "application/json")
            return json.dumps({
                "success": True,
                "playlists": playlists,
                "counts": {
                    "portals": portal_count,
                    "macs": mac_count
                }
            }).encode("utf-8")
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)}).encode("utf-8")
            
            request.setHeader("Content-Type", "application/json")
            return json.dumps({
                "success": True,
                "playlists": playlists,
                "counts": {
                    "portals": portal_count,
                    "macs": mac_count
                }
            }).encode("utf-8")
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)}).encode("utf-8")
    
    def update_playlists(self, request):
        try:
            content = request.content.read().decode("utf-8")
            data = json.loads(content)
            
            if not isinstance(data.get("playlists"), list):
                raise ValueError("Invalid data format")
            
            # Write to temporary file first
            temp_file = self.playlist_file + ".tmp"
            with open(temp_file, "w") as f:
                for item in data["playlists"]:
                    if not item.get("url"):
                        continue
                    
                    f.write(item["url"] + "\n")
                    for mac in item.get("macs", []):
                        if self.mac_pattern.match(mac):
                            # Convert to uppercase for consistent storage
                            f.write(mac.upper() + "\n")
                    f.write("\n")  # Empty line between entries
            
            # Atomically replace the original file
            os.replace(temp_file, self.playlist_file)
            
            # Force Enigma2 to reload the file
            self.screen.update_playlists_display()
            
            return json.dumps({"success": True}).encode("utf-8")
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)}).encode("utf-8")
    
    def validate_portal_mac(self, request):
        content = request.content.read().decode("utf-8")
        try:
            data = json.loads(content)
            url = data.get('url', '')
            mac = data.get('mac', '')
            
            # Validate MAC format
            valid_mac = bool(self.mac_pattern.match(mac))
            
            # Validate portal reachability
            portal_reachable = False
            try:
                # Use HEAD request for efficiency
                response = requests.head(url, timeout=5)
                portal_reachable = response.status_code < 400
            except RequestException:
                portal_reachable = False
            
            return json.dumps({
                "success": True,
                "valid_mac": valid_mac,
                "portal_reachable": portal_reachable
            }).encode("utf-8")
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e)
            }).encode("utf-8")

def main(session, **kwargs):
    session.open(StalkerWebControlScreen)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="EStalker Web Control",
        description="Web interface for managing eStalker playlists",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main,
        icon="plugin_icon.png"
    )